'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
export default function AccountForm({ lang, avatar }) {
  const tx = (a, e) => (lang === 'ar' ? a : e); const r = useRouter(); const [v, setV] = useState(avatar), [msg, setMsg] = useState('');
  const save = async () => {
    const res = await fetch('/api/account', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ avatar_url: v }) });
    const d = await res.json().catch(() => ({})); setMsg(res.ok ? '✓' : d.error || 'Error'); if (res.ok) r.refresh();
  };
  return (<div className="row"><input value={v} onChange={(e) => setV(e.target.value)} placeholder={tx('رابط الصورة الشخصية (https)', 'Avatar image URL (https)')} style={{ direction: 'ltr' }} />
    <button className="btn" onClick={save}>{tx('حفظ', 'Save')}</button>{msg && <span className="muted">{msg}</span>}</div>);
}
