'use client';
import { useState } from 'react';
export default function CodeBlock({ code, lang }) {
  const [ok, setOk] = useState(false);
  const copy = async () => { try { await navigator.clipboard.writeText(code); setOk(true); setTimeout(() => setOk(false), 1500); } catch {} };
  return (<div className="codewrap"><button className="btn" onClick={copy}>{ok ? '✓' : lang === 'ar' ? 'نسخ' : 'Copy'}</button><pre className="code"><code>{code}</code></pre></div>);
}
