'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
export default function HostCreate({ lang }) {
  const tx = (a, e) => (lang === 'ar' ? a : e); const r = useRouter(); const [err, setErr] = useState('');
  const submit = async (e) => {
    e.preventDefault(); setErr('');
    const res = await fetch('/api/hosting', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(e.target))) });
    const d = await res.json().catch(() => ({}));
    if (res.ok) r.push('/hosting/' + d.id); else setErr(d.error || 'Error');
  };
  return (<form className="row" onSubmit={submit} style={{ margin: '16px 0' }}>
    <input name="name" required maxLength={40} placeholder={tx('اسم الاستضافة', 'Server name')} />
    <select name="runtime" className="btn"><option value="node">Node.js</option><option value="python">Python</option></select>
    <button className="btn primary">{tx('إنشاء استضافة', 'Create server')}</button>{err && <span className="err">{err}</span>}</form>);
}
