'use client';
import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
const call = async (id, op, { method = 'GET', body, qs = '', raw } = {}) => {
  const r = await fetch(`/api/hosting/${id}/${op}${qs}`, { method, headers: body ? { 'Content-Type': 'application/json' } : undefined, body: raw || (body ? JSON.stringify(body) : undefined) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Error');
  return d;
};
export default function HostPanel({ id, init, plan, lang }) {
  const tx = (a, e) => (lang === 'ar' ? a : e); const router = useRouter();
  const [tab, setTab] = useState('console'), [status, setStatus] = useState(init.status), [logs, setLogs] = useState(''), [stats, setStats] = useState(null);
  const [msg, setMsg] = useState(''), [busy, setBusy] = useState(false);
  const run = async (fn) => { setBusy(true); setMsg(''); try { await fn(); } catch (e) { setMsg(e.message); } setBusy(false); };
  const refresh = useCallback(async () => {
    try { const [s, l, st] = await Promise.all([call(id, 'status'), call(id, 'logs'), call(id, 'stats')]); setStatus(s.status); setLogs(l.logs); setStats(st); } catch (e) { setMsg(e.message); }
  }, [id]);
  useEffect(() => { refresh(); const t = setInterval(refresh, 4000); return () => clearInterval(t); }, [refresh]);
  const ctl = (op) => run(async () => { await call(id, op, { method: 'POST' }); await refresh(); });
  const box = useRef(null); useEffect(() => { if (box.current) box.current.scrollTop = box.current.scrollHeight; }, [logs]);
  return (<>
    <h2>{init.name} <span className={'badge ' + (status === 'online' ? 'on' : 'off')}>{status === 'online' ? 'Online' : 'Offline'}</span><span className="badge">{init.runtime}</span></h2>
    <div className="row"><button className="btn primary" disabled={busy} onClick={() => ctl('start')}>▶ {tx('تشغيل', 'Start')}</button>
      <button className="btn" disabled={busy} onClick={() => ctl('stop')}>■ {tx('إيقاف', 'Stop')}</button>
      <button className="btn" disabled={busy} onClick={() => ctl('restart')}>↻ {tx('إعادة تشغيل', 'Restart')}</button></div>
    {msg && <p className="err">{msg}</p>}
    <div className="stats" style={{ gridTemplateColumns: 'repeat(2,1fr)' }}>
      <div className="card stat"><b>{stats ? stats.cpu : 0}%</b><span>CPU / {plan.cpu}</span></div>
      <div className="card stat"><b>{stats ? stats.mem_mb : 0}MB</b><span>RAM / {plan.memory_mb}MB</span></div></div>
    <div className="tabs">{[['console', tx('الكونسول', 'Console')], ['files', tx('الملفات', 'Files')], ['settings', tx('الإعدادات', 'Settings')]].map(([k, l]) =>
      <button key={k} className={'btn' + (tab === k ? ' active' : '')} onClick={() => setTab(k)}>{l}</button>)}</div>
    {tab === 'console' && <div className="console" ref={box}>{logs || tx('لا توجد سجلات بعد. ارفع ملفاتك ثم اضغط تشغيل.', 'No logs yet. Upload your files, then press Start.')}</div>}
    {tab === 'files' && <Files id={id} tx={tx} />}
    {tab === 'settings' && <Settings id={id} init={init} tx={tx} router={router} />}
  </>);
}
function Files({ id, tx }) {
  const [path, setPath] = useState(''), [files, setFiles] = useState([]), [open, setOpen] = useState(null), [msg, setMsg] = useState(''), [repo, setRepo] = useState('');
  const load = useCallback(async () => { try { setFiles((await call(id, 'files', { qs: '?path=' + encodeURIComponent(path) })).files); } catch (e) { setMsg(e.message); } }, [id, path]);
  useEffect(() => { load(); }, [load]);
  const join = (n) => (path ? path + '/' + n : n);
  const act = async (fn) => { setMsg(''); try { await fn(); await load(); } catch (e) { setMsg(e.message); } };
  const openFile = (n) => act(async () => { const d = await call(id, 'file', { qs: '?path=' + encodeURIComponent(join(n)) }); setOpen({ path: join(n), content: d.content }); });
  const up = (e) => { const f = e.target.files[0]; if (f) act(async () => { setMsg(tx('جارٍ الرفع...', 'Uploading...')); const d = await call(id, 'upload', { method: 'POST', raw: f }); setMsg(`✓ ${d.files} ${tx('ملف', 'files')}`); }); e.target.value = ''; };
  if (open) return (<div><p className="muted" style={{ direction: 'ltr' }}>{open.path}</p>
    <textarea rows={16} value={open.content} onChange={(e) => setOpen({ ...open, content: e.target.value })} spellCheck={false} />
    <div className="row" style={{ marginTop: 8 }}><button className="btn primary" onClick={() => act(async () => { await call(id, 'file', { method: 'PUT', body: open }); setMsg('✓'); })}>{tx('حفظ', 'Save')}</button>
      <button className="btn" onClick={() => setOpen(null)}>{tx('رجوع', 'Back')}</button></div>{msg && <p className="muted">{msg}</p>}</div>);
  return (<div>
    <div className="row"><label className="btn">{tx('رفع ZIP', 'Upload ZIP')}<input type="file" accept=".zip" hidden onChange={up} /></label>
      <input value={repo} onChange={(e) => setRepo(e.target.value)} placeholder="https://github.com/user/repo" style={{ direction: 'ltr' }} />
      <button className="btn" onClick={() => act(async () => { setMsg(tx('جارٍ الاستيراد...', 'Importing...')); await call(id, 'import', { method: 'POST', body: { repo } }); setMsg('✓'); })}>{tx('استيراد من GitHub', 'Import from GitHub')}</button></div>
    {msg && <p className="muted">{msg}</p>}
    <p style={{ direction: 'ltr', textAlign: 'start' }}><button className="btn" onClick={() => setPath('')}>/</button> {path}
      {path && <button className="btn" style={{ marginInlineStart: 8 }} onClick={() => setPath(path.split('/').slice(0, -1).join('/'))}>..</button>}</p>
    <div className="list">{files.map((f) => (<div className="card row" key={f.name} style={{ justifyContent: 'space-between' }}>
      <a style={{ cursor: 'pointer', direction: 'ltr' }} onClick={() => (f.dir ? setPath(join(f.name)) : openFile(f.name))}>{f.dir ? '📁' : '📄'} {f.name}</a>
      <span className="muted">{f.dir ? '' : Math.ceil(f.size / 1024) + 'KB'}<button className="btn" style={{ marginInlineStart: 8, padding: '2px 8px' }} onClick={() => confirm(tx('حذف؟', 'Delete?')) && act(() => call(id, 'file', { method: 'DELETE', qs: '?path=' + encodeURIComponent(join(f.name)) }))}>✕</button></span></div>))}
      {files.length === 0 && <p className="muted">{tx('المجلد فارغ.', 'Empty folder.')}</p>}</div></div>);
}
function Settings({ id, init, tx, router }) {
  const [name, setName] = useState(init.name), [cmd, setCmd] = useState(init.start_cmd), [keys, setKeys] = useState(init.envKeys), [k, setK] = useState(''), [v, setV] = useState(''), [msg, setMsg] = useState('');
  const patch = async (body) => { setMsg(''); const r = await fetch(`/api/hosting/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); const d = await r.json().catch(() => ({})); if (!r.ok) setMsg(d.error || 'Error'); else { setKeys(d.envKeys); setMsg('✓'); } return r.ok; };
  const del = async () => { if (!confirm(tx('حذف الاستضافة نهائياً؟', 'Delete this server permanently?'))) return; const r = await fetch(`/api/hosting/${id}`, { method: 'DELETE' }); if (r.ok) { router.push('/hosting'); router.refresh(); } else setMsg((await r.json().catch(() => ({}))).error || 'Error'); };
  return (<div className="form">
    <label>{tx('الاسم', 'Name')}</label><input value={name} onChange={(e) => setName(e.target.value)} />
    <label>{tx('أمر التشغيل', 'Start command')}</label><input value={cmd} onChange={(e) => setCmd(e.target.value)} style={{ direction: 'ltr' }} />
    <button className="btn primary" onClick={() => patch({ name, start_cmd: cmd })}>{tx('حفظ', 'Save')}</button>
    <h3>{tx('المتغيرات السرية (التوكن وغيره)', 'Secret variables (token etc.)')}</h3>
    <p className="muted">{tx('القيم مشفّرة ولا تظهر بعد الحفظ.', 'Values are encrypted and never shown again.')}</p>
    {keys.map((x) => <div className="row" key={x}><code style={{ flex: 1 }}>{x}</code><button className="btn" onClick={() => patch({ delEnv: [x] })}>✕</button></div>)}
    <div className="row"><input placeholder="TOKEN" value={k} onChange={(e) => setK(e.target.value)} style={{ direction: 'ltr' }} />
      <input type="password" placeholder={tx('القيمة', 'Value')} value={v} onChange={(e) => setV(e.target.value)} />
      <button className="btn" onClick={async () => { if (k && (await patch({ setEnv: { [k]: v } }))) { setK(''); setV(''); } }}>{tx('إضافة', 'Add')}</button></div>
    {msg && <p className="muted">{msg}</p>}
    <button className="btn" style={{ borderColor: '#f87171', color: '#f87171' }} onClick={del}>{tx('حذف الاستضافة', 'Delete server')}</button></div>);
}
