'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
export default function AuthForm({ mode, t }) {
  const r = useRouter(); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault(); setBusy(true); setErr('');
    const body = Object.fromEntries(new FormData(e.target));
    const res = await fetch(`/api/auth/${mode}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) return setErr(data.error || 'Error');
    r.push('/'); r.refresh();
  }
  return (
    <form className="auth card" onSubmit={submit}>
      <h2 style={{ margin: 0 }}>{mode === 'login' ? t.login : t.register}</h2>
      {mode === 'register' && <input name="username" placeholder={t.username} required minLength={3} maxLength={24} pattern="[A-Za-z0-9_]+" />}
      <input name="email" type="email" placeholder={t.email} required />
      <input name="password" type="password" placeholder={t.password} required minLength={8} />
      <div className="err">{err}</div>
      <button className="btn primary" disabled={busy}>{busy ? t.loading : mode === 'login' ? t.login : t.register}</button>
    </form>
  );
}
