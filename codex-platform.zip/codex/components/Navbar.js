'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
export default function Navbar({ t, lang, theme, user }) {
  const r = useRouter(); const tx = (a, e) => (lang === 'ar' ? a : e);
  const setCookie = (k, v) => { document.cookie = `${k}=${v};path=/;max-age=31536000`; r.refresh(); };
  const logout = async () => { await fetch('/api/auth/logout', { method: 'POST' }); r.push('/'); r.refresh(); };
  return (
    <nav><div className="wrap">
      <Link href="/" className="logo">CODEX</Link>
      <div className="links">
        <Link href="/learn">{tx('تعلّم', 'Learn')}</Link><Link href="/projects">{t.projects}</Link>
        <Link href="/hosting">{tx('الاستضافة', 'Hosting')}</Link>
        {user?.role === 'owner' && <Link href="/admin">{tx('الإدارة', 'Admin')}</Link>}
      </div>
      <form action="/search" className="search"><input name="q" placeholder={tx('بحث...', 'Search...')} required /></form>
      <button className="btn" onClick={() => setCookie('lang', lang === 'ar' ? 'en' : 'ar')}>{lang === 'ar' ? 'EN' : 'عربي'}</button>
      <button className="btn" onClick={() => setCookie('theme', theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? '☀️' : '🌙'}</button>
      {user ? (<><Link className="btn" href="/account">{user.username}</Link><button className="btn" onClick={logout}>{t.logout}</button></>) : (<>
        <Link className="btn" href="/login">{t.login}</Link><Link className="btn primary" href="/register">{t.register}</Link></>)}
    </div></nav>
  );
}
