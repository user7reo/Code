'use client';
import { useState, useEffect, useCallback } from 'react';
import { CFG, TABS } from '@/lib/adminCfg';
const api = async (url, opt = {}) => {
  const r = await fetch(url, { headers: opt.body && typeof opt.body === 'string' ? { 'Content-Type': 'application/json' } : undefined, ...opt });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Error');
  return d;
};
export default function Admin({ lang }) {
  const tx = (a, e) => (lang === 'ar' ? a : e);
  const NAMES = { stats: tx('إحصائيات', 'Stats'), users: tx('الأعضاء والاشتراكات', 'Users & subs'), projects: tx('المشاريع', 'Projects'), lessons: tx('الدروس', 'Lessons'), plans: tx('الخطط', 'Plans'), servers: tx('الاستضافات', 'Servers') };
  const [tab, setTab] = useState('stats'), [rows, setRows] = useState([]), [stats, setStats] = useState(null), [form, setForm] = useState({}), [editId, setEditId] = useState(null), [msg, setMsg] = useState('');
  const cfg = CFG[tab];
  const load = useCallback(async () => {
    setMsg('');
    try { if (tab === 'stats') setStats(await api('/api/admin/stats')); else setRows((await api('/api/admin/' + tab)).rows); } catch (e) { setMsg(e.message); }
  }, [tab]);
  useEffect(() => { setForm({}); setEditId(null); load(); }, [load]);
  const save = async (e) => {
    e.preventDefault();
    try { await api(editId ? `/api/admin/${tab}/${editId}` : `/api/admin/${tab}`, { method: editId ? 'PATCH' : 'POST', body: JSON.stringify(form) }); setForm({}); setEditId(null); load(); } catch (er) { setMsg(er.message); }
  };
  const del = async (id) => { if (!confirm(tx('تأكيد الحذف؟', 'Delete?'))) return; try { await api(`/api/admin/${tab}/${id}`, { method: 'DELETE' }); load(); } catch (er) { setMsg(er.message); } };
  const edit = (row) => { const f = {}; cfg.fields.forEach((x) => { const v = row[x.k]; f[x.k] = v == null ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v); }); setForm(f); setEditId(row.id); window.scrollTo(0, 0); };
  const zip = async (id, file) => { if (!file) return; try { await api('/api/upload/project/' + id, { method: 'POST', body: file }); setMsg('✓ ZIP'); load(); } catch (er) { setMsg(er.message); } };
  const cell = (v) => { const s = v == null ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v); return s.length > 40 ? s.slice(0, 40) + '…' : s; };
  return (<>
    <h2>{tx('لوحة المالك', 'Owner dashboard')}</h2>
    <div className="tabs">{TABS.map((k) => <button key={k} className={'btn' + (tab === k ? ' active' : '')} onClick={() => setTab(k)}>{NAMES[k]}</button>)}</div>
    {msg && <p className="err">{msg}</p>}
    {tab === 'stats' && stats && <div className="stats" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(130px,1fr))' }}>
      {Object.entries(stats).map(([k, v]) => <div className="card stat" key={k}><b>{v}</b><span>{k}</span></div>)}</div>}
    {tab !== 'stats' && (<>
      {(cfg.c || editId) && cfg.fields.length > 0 && (<form className="form card" onSubmit={save}>
        <b>{editId ? tx('تعديل #', 'Edit #') + editId : tx('إضافة جديد', 'Add new')}</b>
        {cfg.fields.map((f) => (<div key={f.k}><label>{f.k}</label>
          {f.t === 'textarea' ? <textarea rows={4} value={form[f.k] || ''} onChange={(e) => setForm({ ...form, [f.k]: e.target.value })} />
            : f.t === 'select' ? <select className="btn" style={{ width: '100%' }} value={form[f.k] || ''} onChange={(e) => setForm({ ...form, [f.k]: e.target.value })}><option value="">—</option>{f.o.map((o) => <option key={o}>{o}</option>)}</select>
              : <input type={f.t === 'number' ? 'number' : 'text'} step="any" value={form[f.k] || ''} onChange={(e) => setForm({ ...form, [f.k]: e.target.value })} style={{ width: '100%' }} />}</div>))}
        {tab === 'lessons' && <p className="muted">quiz: {'[{"q":"…","options":["a","b"],"answer":0}]'}</p>}
        <div className="row"><button className="btn primary">{tx('حفظ', 'Save')}</button>{editId && <button type="button" className="btn" onClick={() => { setEditId(null); setForm({}); }}>{tx('إلغاء', 'Cancel')}</button>}</div></form>)}
      <div className="tbl"><table><thead><tr>{cfg.cols.map((c) => <th key={c}>{c}</th>)}<th /></tr></thead><tbody>
        {rows.map((r) => (<tr key={r.id}>{cfg.cols.map((c) => <td key={c}>{cell(r[c])}</td>)}
          <td className="row">{cfg.fields.length > 0 && <button className="btn" onClick={() => edit(r)}>✎</button>}
            {cfg.zip && <label className="btn">ZIP<input type="file" accept=".zip" hidden onChange={(e) => zip(r.id, e.target.files[0])} /></label>}
            {cfg.d && <button className="btn" onClick={() => del(r.id)}>✕</button>}</td></tr>))}</tbody></table></div></>)}
  </>);
}
