'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
export default function LessonClient({ id, done: d0, loggedIn, playground, quiz, lang, nextId }) {
  const tx = (a, e) => (lang === 'ar' ? a : e); const r = useRouter();
  const [done, setDone] = useState(d0), [code, setCode] = useState(playground || ''), [run, setRun] = useState(playground || '');
  const [ans, setAns] = useState({}), [checked, setChecked] = useState(false), [err, setErr] = useState('');
  const score = (quiz || []).filter((q, i) => ans[i] === q.answer).length;
  const complete = async () => {
    const res = await fetch(`/api/lessons/${id}/complete`, { method: 'POST' });
    if (res.ok) { setDone(true); r.refresh(); } else setErr((await res.json().catch(() => ({}))).error || 'Error');
  };
  return (<>
    {playground && (<><h2>{tx('جرّب بنفسك', 'Try it yourself')}</h2>
      <textarea rows={8} value={code} onChange={(e) => setCode(e.target.value)} spellCheck={false} />
      <div className="row" style={{ margin: '8px 0' }}><button className="btn primary" onClick={() => setRun(code)}>{tx('تشغيل', 'Run')}</button></div>
      <iframe className="pg" sandbox="allow-scripts" srcDoc={run} title="preview" /></>)}
    {quiz?.length > 0 && (<><h2>{tx('اختبار', 'Quiz')}</h2>
      {quiz.map((q, i) => (<div className="card" key={i} style={{ marginBottom: 8 }}><b>{q.q}</b>
        {q.options.map((o, j) => (<div key={j}><label><input type="radio" name={'q' + i} onChange={() => { setAns({ ...ans, [i]: j }); setChecked(false); }} /> {o}</label></div>))}</div>))}
      <button className="btn" onClick={() => setChecked(true)}>{tx('تحقق', 'Check')}</button>
      {checked && <p className={score === quiz.length ? 'ok' : 'muted'}>{score}/{quiz.length}</p>}</>)}
    <div className="row" style={{ margin: '24px 0' }}>
      {loggedIn ? <button className="btn primary" disabled={done} onClick={complete}>{done ? tx('✓ مكتمل', '✓ Completed') : tx('إكمال الدرس', 'Mark complete')}</button>
        : <Link className="btn" href="/login">{tx('سجّل الدخول لحفظ تقدمك', 'Log in to save progress')}</Link>}
      {nextId && <Link className="btn" href={`/learn/${nextId}`}>{tx('الدرس التالي', 'Next lesson')}</Link>}
    </div>{err && <p className="err">{err}</p>}
  </>);
}
