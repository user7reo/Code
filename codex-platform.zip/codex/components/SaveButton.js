'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
export default function SaveButton({ id, saved: s0, loggedIn, lang }) {
  const tx = (a, e) => (lang === 'ar' ? a : e); const r = useRouter(); const [saved, setSaved] = useState(s0);
  const click = async () => {
    if (!loggedIn) return r.push('/login');
    const res = await fetch(`/api/projects/${id}/save`, { method: 'POST' });
    if (res.ok) setSaved((await res.json()).saved);
  };
  return <button className="btn" onClick={click}>{saved ? tx('★ محفوظ', '★ Saved') : tx('☆ حفظ', '☆ Save')}</button>;
}
