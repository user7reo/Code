const { Pool } = require('pg'); const fs = require('fs'); const path = require('path');
if (fs.existsSync('.env')) fs.readFileSync('.env','utf8').split('\n').forEach(l=>{const m=l.match(/^([A-Z_]+)=(.*)$/); if(m&&!process.env[m[1]]) process.env[m[1]]=m[2];});
(async()=>{ const p=new Pool({connectionString:process.env.DATABASE_URL});
 await p.query(fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8')); console.log('DB ready'); await p.end(); })().catch(e=>{console.error(e);process.exit(1)});
