// Starter lessons (only inserted when the lessons table is empty). Add/edit more from the Owner Dashboard.
const { Pool } = require('pg'); const fs = require('fs');
if (fs.existsSync('.env')) fs.readFileSync('.env','utf8').split('\n').forEach(l=>{const m=l.match(/^([A-Z_]+)=(.*)$/); if(m&&!process.env[m[1]]) process.env[m[1]]=m[2];});
const J = a => a.join('\n');
const L = [
 { title:'أول صفحة HTML', language:'HTML', level:'beginner', position:1,
   content:'HTML هي لغة بناء هيكل صفحات الويب.\n\nكل صفحة تبدأ بالوسم html وتحتوي على head للمعلومات وbody للمحتوى الظاهر.',
   code:J(['<!DOCTYPE html>','<html lang="ar" dir="rtl">','<head><meta charset="UTF-8"><title>صفحتي</title></head>','<body>','  <h1>مرحباً بالعالم</h1>','  <p>هذه أول صفحة ويب لي.</p>','</body>','</html>']),
   code_explain:'h1 يعرض عنواناً رئيسياً، وp يعرض فقرة نصية. جرّب تغيير النص أدناه ثم اضغط تشغيل.',
   playground:J(['<h1>مرحباً بالعالم</h1>','<p>غيّر هذا النص وشاهد النتيجة.</p>']),
   quiz:[{q:'أي وسم يعرض عنواناً رئيسياً؟',options:['p','h1','body'],answer:1}] },
 { title:'ألوان وخطوط CSS', language:'CSS', level:'beginner', position:1,
   content:'CSS تتحكم بشكل الصفحة: الألوان والخطوط والمسافات.\n\nكل قاعدة تتكون من محدد (مثل h1) وخصائص بين أقواس.',
   code:J(['h1 {','  color: rebeccapurple;','  font-size: 32px;','}']),
   code_explain:'color يغيّر لون النص، وfont-size يغيّر حجمه.',
   playground:J(['<style>','h1 { color: rebeccapurple; font-size: 32px; }','</style>','<h1>CODEX</h1>']),
   quiz:[{q:'أي خاصية تغيّر لون النص؟',options:['color','size','margin'],answer:0}] },
 { title:'المتغيرات والدوال في JavaScript', language:'JavaScript', level:'beginner', position:1,
   content:'المتغير يخزّن قيمة، والدالة تجمّع خطوات يمكن إعادة استخدامها.\n\nاستخدم const للقيم التي لا تتغير وlet للقيم المتغيرة.',
   code:J(['const name = "CODEX";','function greet(user) {','  return "أهلاً " + user;','}','console.log(greet(name));']),
   code_explain:'نعرّف دالة greet تستقبل اسماً وترجع جملة ترحيب، ثم نطبعها في الكونسول.',
   playground:J(['<p id="out"></p>','<script>','function greet(user){ return "أهلاً " + user; }','document.getElementById("out").textContent = greet("CODEX");','</script>']),
   quiz:[{q:'أي كلمة تعرّف قيمة ثابتة؟',options:['let','const','function'],answer:1}] },
 { title:'أول برنامج بايثون', language:'Python', level:'beginner', position:1,
   content:'بايثون لغة سهلة القراءة تُستخدم في الويب والبوتات والذكاء الاصطناعي.\n\nالدالة print تطبع النص، والمتغيرات تُعرّف بدون كلمات خاصة.',
   code:J(['name = "CODEX"','print("أهلاً", name)','for i in range(3):','    print(i)']),
   code_explain:'نخزّن نصاً في name ونطبعه، ثم حلقة for تطبع الأرقام 0 و1 و2.',
   playground:'', quiz:[{q:'أي دالة تطبع نصاً؟',options:['echo','print','log'],answer:1}] },
 { title:'أول خادم Node.js', language:'Node.js', level:'beginner', position:1,
   content:'Node.js يشغّل JavaScript خارج المتصفح، ويُستخدم لبناء الخوادم والبوتات.\n\nالوحدة http المدمجة تكفي لخادم بسيط.',
   code:J(["const http = require('http');","http.createServer((req, res) => {","  res.end('Hello from Node.js');","}).listen(3000);"]),
   code_explain:'ننشئ خادماً يرد بنص ثابت على كل طلب على المنفذ 3000.',
   playground:'', quiz:[{q:'أي وحدة مدمجة تنشئ خادم ويب؟',options:['fs','http','path'],answer:1}] },
 { title:'أول بوت Discord.js', language:'Discord.js', level:'intermediate', position:1,
   content:'لتشغيل بوت تحتاج توكن من Discord Developer Portal. لا تضع التوكن في الكود أبداً، بل في متغير بيئة.\n\nعلى استضافة CODEX أضف المتغير TOKEN من تبويب الإعدادات.',
   code:J(["const { Client, GatewayIntentBits } = require('discord.js');","const client = new Client({ intents: [GatewayIntentBits.Guilds] });","client.once('ready', () => console.log('Logged in as ' + client.user.tag));","client.login(process.env.TOKEN);"]),
   code_explain:'ننشئ عميلاً بصلاحية Guilds، ونطبع اسم البوت عند الاتصال، ثم نسجّل الدخول بالتوكن من البيئة.',
   playground:'', quiz:[{q:'أين يجب تخزين توكن البوت؟',options:['داخل الكود','متغير بيئة','في ملف README'],answer:1}] },
 { title:'مقدمة في BDScript', language:'BDScript', level:'beginner', position:1,
   content:'BDScript هي لغة دوال تُستخدم في Bot Designer for Discord. كل دالة تبدأ بعلامة $ ويستبدلها البوت بقيمتها عند التنفيذ.\n\nراجع توثيق BDFD الرسمي لقائمة الدوال الكاملة.',
   code:'أهلاً $username!',
   code_explain:'الدالة $username تُستبدل باسم المستخدم الذي نفّذ الأمر.',
   playground:'', quiz:[{q:'بماذا تبدأ الدوال في BDScript؟',options:['#','$','@'],answer:1}] },
];
(async()=>{ const p=new Pool({connectionString:process.env.DATABASE_URL});
 const {rows}=await p.query('SELECT count(*)::int c FROM lessons');
 if(rows[0].c>0){console.log('Lessons exist, skipping seed');return p.end();}
 for(const l of L) await p.query('INSERT INTO lessons (title,language,level,position,content,code,code_explain,playground,quiz) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)',[l.title,l.language,l.level,l.position,l.content,l.code,l.code_explain,l.playground,JSON.stringify(l.quiz)]);
 console.log('Seeded',L.length,'lessons'); await p.end(); })().catch(e=>{console.error(e);process.exit(1)});
