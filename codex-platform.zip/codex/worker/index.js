// CODEX hosting worker: runs every user project in its own resource-limited Docker container.
// Run this on a SEPARATE server (or at least outside the web app). It needs access to the Docker socket.
const express = require('express'), crypto = require('crypto'), Docker = require('dockerode'), AdmZip = require('adm-zip');
const fs = require('fs'), path = require('path'), { execFile } = require('child_process');
const docker = new Docker();
const DATA = path.resolve(process.env.WORKER_DATA || './data');
const SECRET = process.env.WORKER_SECRET || '';
if (SECRET.length < 16) { console.error('WORKER_SECRET must be 16+ chars'); process.exit(1); }
const IMG = { node: 'node:20-alpine', python: 'python:3.12-alpine' };
const bad = (s, m) => Object.assign(new Error(m), { status: s });
const wrap = (fn) => async (req, res) => {
  try { res.json((await fn(req)) ?? { ok: true }); }
  catch (e) { res.status(e.status || 500).json({ error: e.status ? e.message : 'Worker error: ' + e.message }); }
};
const app = express();
app.use((req, res, next) => {
  const a = Buffer.from(req.get('x-worker-secret') || ''), b = Buffer.from(SECRET);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'unauthorized' });
  next();
});
const sid = (id) => { if (!/^\d{1,9}$/.test(id)) throw bad(400, 'bad id'); return id; };
const base = (id) => { const d = path.join(DATA, 'servers', sid(id)); fs.mkdirSync(d, { recursive: true }); return d; };
// Resolve a user-supplied path and make sure it (and any symlink target) stays inside the server directory.
const inside = (b, rel) => {
  const rb = fs.realpathSync(b), full = path.resolve(b, String(rel || '.'));
  if (full !== b && !full.startsWith(b + path.sep)) throw bad(400, 'bad path');
  let p = full; while (!fs.existsSync(p)) p = path.dirname(p);
  const real = fs.realpathSync(p);
  if (real !== rb && !real.startsWith(rb + path.sep)) throw bad(400, 'bad path');
  return full;
};
const cname = (id) => 'codex-srv-' + sid(id);
async function getC(id) {
  const c = docker.getContainer(cname(id));
  try { return { c, i: await c.inspect() }; } catch (e) { if (e.statusCode === 404) return { c: null, i: null }; throw e; }
}
const kill = async (id) => { const { c } = await getC(id); if (c) await c.remove({ force: true }); };
async function ensureImage(img) {
  try { await docker.getImage(img).inspect(); }
  catch { await new Promise((ok, no) => docker.pull(img, (e, s) => e ? no(e) : docker.modem.followProgress(s, (er) => er ? no(er) : ok()))); }
}
async function start(id, cfg) {
  const rt = cfg.runtime; if (!IMG[rt]) throw bad(400, 'bad runtime');
  const cmd = String(cfg.start_cmd || '').slice(0, 200).replace(/[\r\n]/g, ' ').trim();
  if (!cmd) throw bad(400, 'start command required');
  const dir = base(id); fs.mkdirSync(path.join(dir, '.home'), { recursive: true });
  await kill(id); await ensureImage(IMG[rt]);
  const pre = rt === 'node' ? '[ -f package.json ] && npm install --no-audit --no-fund; ' : '[ -f requirements.txt ] && pip install --no-cache-dir -r requirements.txt --target /app/.pylibs; ';
  const env = Object.entries(cfg.env || {}).map(([k, v]) => k + '=' + v);
  env.push('HOME=/app/.home', 'npm_config_cache=/app/.npm', 'PYTHONPATH=/app/.pylibs', 'PYTHONUNBUFFERED=1');
  const mem = Math.max(64, Number(cfg.memory_mb) || 256) * 1048576;
  const c = await docker.createContainer({
    Image: IMG[rt], name: cname(id), Cmd: ['sh', '-c', pre + cmd], WorkingDir: '/app',
    User: process.getuid() + ':' + process.getgid(), Env: env, Labels: { codex: '1' },
    HostConfig: { Binds: [dir + ':/app'], Memory: mem, MemorySwap: mem, NanoCpus: Math.round((Number(cfg.cpu) || 0.5) * 1e9),
      PidsLimit: 128, CapDrop: ['ALL'], SecurityOpt: ['no-new-privileges'], RestartPolicy: { Name: 'on-failure', MaximumRetryCount: 3 } },
  });
  await c.start();
}
function demux(buf) { let o = '', i = 0; while (i + 8 <= buf.length) { const n = buf.readUInt32BE(i + 4); o += buf.slice(i + 8, i + 8 + n).toString('utf8'); i += 8 + n; } return o; }

app.post('/servers/:id/start', express.json(), wrap((r) => start(r.params.id, r.body || {})));
app.post('/servers/:id/stop', wrap(async (r) => { const { c } = await getC(r.params.id); if (c) { try { await c.stop({ t: 5 }); } catch (e) { if (e.statusCode !== 304) throw e; } } }));
app.get('/servers/:id/status', wrap(async (r) => { const { i } = await getC(r.params.id); return { status: i && i.State.Running ? 'online' : 'offline', exit_code: i ? i.State.ExitCode : null }; }));
app.get('/servers/:id/logs', wrap(async (r) => { const { c } = await getC(r.params.id); return { logs: c ? demux(await c.logs({ stdout: true, stderr: true, tail: 300 })) : '' }; }));
app.get('/servers/:id/stats', wrap(async (r) => {
  const { c, i } = await getC(r.params.id);
  if (!c || !i.State.Running) return { cpu: 0, mem_mb: 0, mem_limit_mb: 0 };
  const s = await c.stats({ stream: false });
  const cd = (s.cpu_stats.cpu_usage.total_usage || 0) - (s.precpu_stats.cpu_usage.total_usage || 0);
  const sd = (s.cpu_stats.system_cpu_usage || 0) - (s.precpu_stats.system_cpu_usage || 0);
  return { cpu: +(sd > 0 ? cd / sd * (s.cpu_stats.online_cpus || 1) * 100 : 0).toFixed(1),
    mem_mb: +((s.memory_stats.usage || 0) / 1048576).toFixed(1), mem_limit_mb: Math.round((s.memory_stats.limit || 0) / 1048576) };
}));
app.get('/servers/:id/files', wrap(async (r) => {
  const b = base(r.params.id), d = inside(b, r.query.path);
  if (!fs.statSync(d).isDirectory()) throw bad(400, 'not a directory');
  return { files: fs.readdirSync(d).map((n) => { const st = fs.lstatSync(path.join(d, n)); return { name: n, dir: st.isDirectory(), size: st.isFile() ? st.size : 0 }; })
    .sort((a, b) => b.dir - a.dir || a.name.localeCompare(b.name)) };
}));
app.get('/servers/:id/file', wrap(async (r) => {
  const f = inside(base(r.params.id), r.query.path), st = fs.statSync(f);
  if (!st.isFile() || st.size > 1048576) throw bad(400, 'not a file or larger than 1MB');
  return { content: fs.readFileSync(f, 'utf8') };
}));
app.put('/servers/:id/file', express.json({ limit: '2mb' }), wrap(async (r) => {
  const b = base(r.params.id), f = inside(b, r.body.path);
  if (f === b) throw bad(400, 'bad path');
  fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, String(r.body.content ?? ''));
}));
app.delete('/servers/:id/file', wrap(async (r) => {
  const b = base(r.params.id), f = inside(b, r.query.path);
  if (f === b) throw bad(400, 'bad path');
  fs.rmSync(f, { recursive: true, force: true });
}));
app.post('/servers/:id/upload', express.raw({ limit: '50mb', type: () => true }), wrap(async (r) => {
  const id = r.params.id, dir = base(id); await kill(id);
  let z; try { z = new AdmZip(r.body); } catch { throw bad(400, 'invalid zip'); }
  const es = z.getEntries().filter((e) => !e.isDirectory && !e.entryName.startsWith('__MACOSX'));
  if (!es.length) throw bad(400, 'empty zip');
  if (es.reduce((s, e) => s + e.header.size, 0) > 300 * 1048576) throw bad(400, 'zip too large when extracted');
  const tops = new Set(es.map((e) => e.entryName.split('/')[0]));
  const strip = tops.size === 1 && es.every((e) => e.entryName.includes('/')) ? [...tops][0] + '/' : '';
  for (const e of es) { const f = inside(dir, e.entryName.slice(strip.length)); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, e.getData()); }
  return { files: es.length };
}));
app.post('/servers/:id/import', express.json(), wrap(async (r) => {
  const repo = String((r.body || {}).repo || '');
  if (!/^https:\/\/github\.com\/[\w.-]+\/[\w.-]+?(\.git)?$/.test(repo)) throw bad(400, 'Use a public https://github.com/user/repo URL');
  const id = r.params.id, dir = base(id); await kill(id);
  fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  await new Promise((ok, no) => execFile('git', ['clone', '--depth', '1', '--', repo, '.'], { cwd: dir, timeout: 120000, env: { PATH: process.env.PATH, GIT_TERMINAL_PROMPT: '0' } }, (e) => e ? no(bad(400, 'git clone failed')) : ok()));
  fs.rmSync(path.join(dir, '.git'), { recursive: true, force: true });
}));
app.delete('/servers/:id', wrap(async (r) => { await kill(r.params.id); fs.rmSync(base(r.params.id), { recursive: true, force: true }); }));
app.listen(process.env.PORT || 4000, process.env.HOST || '127.0.0.1', () => console.log('CODEX worker up'));
