import bcrypt from 'bcryptjs';
import { pool } from '@/lib/db';
import { createSession } from '@/lib/auth';
export async function POST(req) {
  const { username = '', email = '', password = '' } = await req.json().catch(() => ({}));
  if (!/^[A-Za-z0-9_]{3,24}$/.test(username)) return Response.json({ error: 'Invalid username' }, { status: 400 });
  if (!/^\S+@\S+\.\S+$/.test(email)) return Response.json({ error: 'Invalid email' }, { status: 400 });
  if (password.length < 8) return Response.json({ error: 'Password must be 8+ characters' }, { status: 400 });
  const role = process.env.OWNER_EMAIL && email.toLowerCase() === process.env.OWNER_EMAIL.toLowerCase() ? 'owner' : 'user';
  try {
    const hash = await bcrypt.hash(password, 12);
    const { rows } = await pool.query('INSERT INTO users (username,email,password_hash,role) VALUES ($1,$2,$3,$4) RETURNING id', [username, email.toLowerCase(), hash, role]);
    await createSession(rows[0].id);
    return Response.json({ ok: true });
  } catch (e) {
    if (e.code === '23505') return Response.json({ error: 'Username or email already used' }, { status: 409 });
    console.error(e); return Response.json({ error: 'Server error' }, { status: 500 });
  }
}
