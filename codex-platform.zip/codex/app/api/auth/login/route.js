import bcrypt from 'bcryptjs';
import { pool } from '@/lib/db';
import { createSession } from '@/lib/auth';
import { log } from '@/lib/servers';
export async function POST(req) {
  const { email = '', password = '' } = await req.json().catch(() => ({}));
  const { rows } = await pool.query('SELECT id,password_hash,banned FROM users WHERE email=$1', [email.toLowerCase()]);
  const u = rows[0];
  if (!u || !(await bcrypt.compare(password, u.password_hash))) return Response.json({ error: 'Wrong email or password' }, { status: 401 });
  if (u.banned) return Response.json({ error: 'Account banned' }, { status: 403 });
  await createSession(u.id); await log(u.id, 'login');
  return Response.json({ ok: true });
}
