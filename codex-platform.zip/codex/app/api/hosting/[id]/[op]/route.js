import { pool } from '@/lib/db';
import { handle, needUser, HttpError } from '@/lib/guard';
import { own, getPlan, log } from '@/lib/servers';
import { dec } from '@/lib/crypto';
import { worker } from '@/lib/worker';
const READ = ['status', 'logs', 'stats', 'files', 'file'];
const setStatus = (id, st) => pool.query('UPDATE servers SET status=$1 WHERE id=$2', [st, id]);
export const GET = handle(async (req, { params }) => {
  const u = await needUser(); const s = await own(params.id, u);
  if (!READ.includes(params.op)) throw new HttpError(404, 'Not found');
  const d = await worker(`/servers/${s.id}/${params.op}${new URL(req.url).search}`);
  if (params.op === 'status' && d.status !== s.status) await setStatus(s.id, d.status);
  return Response.json(d);
});
export const POST = handle(async (req, { params }) => {
  const u = await needUser(); const s = await own(params.id, u); const op = params.op;
  if (op === 'start' || op === 'restart') {
    const plan = await getPlan(s.user_id);
    await worker(`/servers/${s.id}/start`, { method: 'POST', body: { runtime: s.runtime, start_cmd: s.start_cmd, env: dec(s.env_enc), memory_mb: plan.memory_mb, cpu: Number(plan.cpu) } });
    await setStatus(s.id, 'online'); await log(u.id, 'server_' + op, s.name);
    return Response.json({ ok: true });
  }
  if (op === 'stop') { await worker(`/servers/${s.id}/stop`, { method: 'POST' }); await setStatus(s.id, 'offline'); return Response.json({ ok: true }); }
  if (op === 'upload') {
    const buf = Buffer.from(await req.arrayBuffer());
    if (!buf.length || buf.length > 50 * 1048576) throw new HttpError(400, 'ZIP must be between 1 byte and 50MB');
    const d = await worker(`/servers/${s.id}/upload`, { method: 'POST', raw: buf });
    await setStatus(s.id, 'offline'); await log(u.id, 'server_upload', s.name);
    return Response.json(d);
  }
  if (op === 'import') {
    const b = await req.json().catch(() => ({}));
    await worker(`/servers/${s.id}/import`, { method: 'POST', body: { repo: b.repo } });
    await setStatus(s.id, 'offline'); await log(u.id, 'server_import', s.name);
    return Response.json({ ok: true });
  }
  throw new HttpError(404, 'Not found');
});
export const PUT = handle(async (req, { params }) => {
  const u = await needUser(); const s = await own(params.id, u);
  if (params.op !== 'file') throw new HttpError(404, 'Not found');
  const b = await req.json().catch(() => ({}));
  return Response.json(await worker(`/servers/${s.id}/file`, { method: 'PUT', body: { path: b.path, content: b.content } }));
});
export const DELETE = handle(async (req, { params }) => {
  const u = await needUser(); const s = await own(params.id, u);
  if (params.op !== 'file') throw new HttpError(404, 'Not found');
  return Response.json(await worker(`/servers/${s.id}/file${new URL(req.url).search}`, { method: 'DELETE' }));
});
