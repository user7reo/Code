import { pool } from '@/lib/db';
import { handle, needUser, HttpError } from '@/lib/guard';
import { own, log } from '@/lib/servers';
import { enc, dec } from '@/lib/crypto';
import { worker } from '@/lib/worker';
export const PATCH = handle(async (req, { params }) => {
  const u = await needUser(); const s = await own(params.id, u); const b = await req.json().catch(() => ({}));
  const sets = [], v = [];
  if (b.name !== undefined) { const n = String(b.name).trim(); if (!n || n.length > 40) throw new HttpError(400, 'Invalid name'); v.push(n); sets.push(`name=$${v.length}`); }
  if (b.start_cmd !== undefined) { const c = String(b.start_cmd).trim(); if (!c || c.length > 200 || /[\r\n]/.test(c)) throw new HttpError(400, 'Invalid command'); v.push(c); sets.push(`start_cmd=$${v.length}`); }
  if (b.setEnv || b.delEnv) {
    const e = dec(s.env_enc);
    for (const k of b.delEnv || []) delete e[k];
    for (const [k, val] of Object.entries(b.setEnv || {})) {
      if (!/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(k) || String(val).length > 2000) throw new HttpError(400, 'Invalid variable');
      e[k] = String(val);
    }
    if (Object.keys(e).length > 30) throw new HttpError(400, 'Too many variables');
    v.push(enc(e)); sets.push(`env_enc=$${v.length}`);
  }
  if (sets.length) { v.push(s.id); await pool.query(`UPDATE servers SET ${sets.join(',')} WHERE id=$${v.length}`, v); }
  const { rows: [n] } = await pool.query('SELECT env_enc FROM servers WHERE id=$1', [s.id]);
  return Response.json({ ok: true, envKeys: Object.keys(dec(n.env_enc)) });
});
export const DELETE = handle(async (_req, { params }) => {
  const u = await needUser(); const s = await own(params.id, u);
  await worker(`/servers/${s.id}`, { method: 'DELETE' });
  await pool.query('DELETE FROM servers WHERE id=$1', [s.id]);
  await log(u.id, 'server_delete', s.name);
  return Response.json({ ok: true });
});
