import { pool } from '@/lib/db';
import { handle, needUser, HttpError } from '@/lib/guard';
import { getPlan, log } from '@/lib/servers';
export const POST = handle(async (req) => {
  const u = await needUser(); const b = await req.json().catch(() => ({}));
  const name = String(b.name || '').trim();
  if (!name || name.length > 40) throw new HttpError(400, 'Invalid name');
  if (!['node', 'python'].includes(b.runtime)) throw new HttpError(400, 'Invalid runtime');
  const plan = await getPlan(u.id);
  const { rows: [{ c }] } = await pool.query('SELECT count(*)::int c FROM servers WHERE user_id=$1', [u.id]);
  if (u.role !== 'owner' && c >= plan.max_servers) throw new HttpError(403, 'Your plan limit is reached');
  const cmd = b.runtime === 'node' ? 'node index.js' : 'python main.py';
  const { rows: [s] } = await pool.query('INSERT INTO servers (user_id,name,runtime,start_cmd) VALUES ($1,$2,$3,$4) RETURNING id', [u.id, name, b.runtime, cmd]);
  await log(u.id, 'server_create', name);
  return Response.json({ id: s.id });
});
