import fs from 'fs';
import path from 'path';
import { pool } from '@/lib/db';
import { handle, needOwner, HttpError } from '@/lib/guard';
export const POST = handle(async (req, { params }) => {
  await needOwner();
  if (!/^\d{1,9}$/.test(params.id)) throw new HttpError(404, 'Not found');
  const buf = Buffer.from(await req.arrayBuffer());
  if (!buf.length || buf.length > 100 * 1048576) throw new HttpError(400, 'ZIP must be 1 byte to 100MB');
  if (buf.slice(0, 2).toString() !== 'PK') throw new HttpError(400, 'Not a ZIP file');
  const dir = path.resolve(process.env.DATA_DIR || './data', 'projects'); fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${params.id}.zip`); fs.writeFileSync(file, buf);
  await pool.query('UPDATE projects SET zip_path=$1 WHERE id=$2', [file, params.id]);
  return Response.json({ ok: true });
});
