import { pool } from '@/lib/db';
import { handle, needUser, HttpError } from '@/lib/guard';
export const PATCH = handle(async (req) => {
  const u = await needUser(); const b = await req.json().catch(() => ({}));
  const url = String(b.avatar_url || '').trim();
  if (url && (!/^https:\/\/\S+$/.test(url) || url.length > 300)) throw new HttpError(400, 'Avatar must be an https:// link');
  await pool.query('UPDATE users SET avatar_url=$1 WHERE id=$2', [url || null, u.id]);
  return Response.json({ ok: true });
});
