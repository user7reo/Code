import fs from 'fs';
import path from 'path';
import { Readable } from 'stream';
import { pool } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { log } from '@/lib/servers';
export async function GET(_req, { params }) {
  if (!/^\d{1,9}$/.test(params.id)) return new Response('Not found', { status: 404 });
  const { rows } = await pool.query('UPDATE projects SET downloads=downloads+1 WHERE id=$1 RETURNING title,zip_path,download_url', [params.id]);
  const p = rows[0]; if (!p) return new Response('Not found', { status: 404 });
  const u = await getUser(); if (u) log(u.id, 'project_download', p.title);
  if (p.zip_path && fs.existsSync(p.zip_path)) {
    const name = p.title.replace(/[^\w.-]+/g, '_') + '.zip';
    return new Response(Readable.toWeb(fs.createReadStream(p.zip_path)), { headers: { 'Content-Type': 'application/zip', 'Content-Disposition': `attachment; filename="${name}"`, 'Content-Length': String(fs.statSync(p.zip_path).size) } });
  }
  if (p.download_url && /^https?:\/\//.test(p.download_url)) return Response.redirect(p.download_url, 302);
  return new Response('No file available for this project', { status: 404 });
}
