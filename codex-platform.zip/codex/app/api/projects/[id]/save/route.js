import { pool } from '@/lib/db';
import { handle, needUser, HttpError } from '@/lib/guard';
export const POST = handle(async (_req, { params }) => {
  const u = await needUser();
  if (!/^\d{1,9}$/.test(params.id)) throw new HttpError(404, 'Not found');
  const del = await pool.query('DELETE FROM saved_projects WHERE user_id=$1 AND project_id=$2', [u.id, params.id]);
  if (del.rowCount) return Response.json({ saved: false });
  await pool.query('INSERT INTO saved_projects (user_id,project_id) VALUES ($1,$2)', [u.id, params.id]);
  return Response.json({ saved: true });
});
