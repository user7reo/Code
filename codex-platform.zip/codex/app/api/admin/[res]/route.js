import { pool } from '@/lib/db';
import { handle, needOwner, HttpError } from '@/lib/guard';
import { CFG } from '@/lib/adminCfg';
import { norm } from '@/lib/adminNorm';
const T = { users: 'users', projects: 'projects', lessons: 'lessons', plans: 'plans', servers: 'servers' };
const LIST = { servers: 'SELECT s.id,s.name,s.runtime,s.status,u.username FROM servers s JOIN users u ON u.id=s.user_id ORDER BY s.id DESC LIMIT 300',
  users: 'SELECT id,username,email,role,banned,plan_id,plan_expires,created_at FROM users ORDER BY id DESC LIMIT 300' };
export const GET = handle(async (_req, { params }) => {
  await needOwner(); const res = params.res;
  if (res === 'stats') {
    const q = (s) => pool.query(s).then((r) => r.rows[0].c);
    return Response.json({ users: await q('SELECT count(*)::int c FROM users'), projects: await q('SELECT count(*)::int c FROM projects'), lessons: await q('SELECT count(*)::int c FROM lessons'),
      servers: await q('SELECT count(*)::int c FROM servers'), online: await q("SELECT count(*)::int c FROM servers WHERE status='online'"), downloads: await q('SELECT coalesce(sum(downloads),0)::int c FROM projects') });
  }
  if (!T[res]) throw new HttpError(404, 'Not found');
  const { rows } = await pool.query(LIST[res] || `SELECT * FROM ${T[res]} ORDER BY id DESC LIMIT 300`);
  return Response.json({ rows });
});
export const POST = handle(async (req, { params }) => {
  await needOwner(); const cfg = CFG[params.res];
  if (!cfg || !cfg.c) throw new HttpError(404, 'Not found');
  const b = await req.json().catch(() => ({}));
  const cols = cfg.fields.map((f) => f.k).filter((k) => b[k] !== undefined && b[k] !== '');
  if (!cols.length) throw new HttpError(400, 'Empty form');
  const { rows } = await pool.query(`INSERT INTO ${T[params.res]} (${cols.join(',')}) VALUES (${cols.map((_, i) => '$' + (i + 1)).join(',')}) RETURNING id`, cols.map((k) => norm(k, b[k])));
  return Response.json({ id: rows[0].id });
});
