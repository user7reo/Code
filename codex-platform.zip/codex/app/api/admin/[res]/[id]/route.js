import { pool } from '@/lib/db';
import { handle, needOwner, HttpError } from '@/lib/guard';
import { CFG } from '@/lib/adminCfg';
import { worker } from '@/lib/worker';
import { norm } from '@/lib/adminNorm';
const T = { users: 'users', projects: 'projects', lessons: 'lessons', plans: 'plans', servers: 'servers' };
const chk = (res, id) => { if (!CFG[res] || !/^\d{1,9}$/.test(id)) throw new HttpError(404, 'Not found'); };
export const PATCH = handle(async (req, { params }) => {
  const me = await needOwner(); chk(params.res, params.id);
  if (params.res === 'users' && Number(params.id) === me.id) throw new HttpError(400, 'You cannot edit your own account here');
  const b = await req.json().catch(() => ({}));
  const cols = CFG[params.res].fields.map((f) => f.k).filter((k) => b[k] !== undefined);
  if (!cols.length) throw new HttpError(400, 'Nothing to update');
  await pool.query(`UPDATE ${T[params.res]} SET ${cols.map((k, i) => `${k}=$${i + 1}`).join(',')} WHERE id=$${cols.length + 1}`,
    [...cols.map((k) => (b[k] === '' ? null : norm(k, b[k]))), params.id]);
  return Response.json({ ok: true });
});
export const DELETE = handle(async (_req, { params }) => {
  await needOwner(); chk(params.res, params.id);
  const cfg = CFG[params.res]; if (!cfg.d) throw new HttpError(405, 'Not allowed');
  if (params.res === 'servers') await worker(`/servers/${params.id}`, { method: 'DELETE' });
  if (params.res === 'plans') { const { rows } = await pool.query('SELECT count(*)::int c FROM plans'); if (rows[0].c <= 1) throw new HttpError(400, 'Keep at least one plan'); }
  await pool.query(`DELETE FROM ${T[params.res]} WHERE id=$1`, [params.id]);
  return Response.json({ ok: true });
});
