import { pool } from '@/lib/db';
import { handle, needUser, HttpError } from '@/lib/guard';
import { log } from '@/lib/servers';
export const POST = handle(async (_req, { params }) => {
  const u = await needUser();
  if (!/^\d{1,9}$/.test(params.id)) throw new HttpError(404, 'Not found');
  const { rows } = await pool.query('SELECT title FROM lessons WHERE id=$1', [params.id]);
  if (!rows[0]) throw new HttpError(404, 'Not found');
  await pool.query('INSERT INTO lesson_progress (user_id,lesson_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [u.id, params.id]);
  await log(u.id, 'lesson_complete', rows[0].title);
  return Response.json({ ok: true });
});
