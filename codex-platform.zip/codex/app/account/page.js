import Link from 'next/link';
import { redirect } from 'next/navigation';
import { pool } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { getLang, tr } from '@/lib/i18n';
import AccountForm from '@/components/AccountForm';
export const dynamic = 'force-dynamic';
export default async function Account() {
  const u = await getUser(); if (!u) redirect('/login');
  const lang = getLang(), tx = tr(lang), q = (s) => pool.query(s, [u.id]).then((r) => r.rows);
  const [prog, saved, servers, act] = await Promise.all([
    q('SELECT l.id,l.title FROM lesson_progress p JOIN lessons l ON l.id=p.lesson_id WHERE p.user_id=$1 ORDER BY p.done_at DESC'),
    q('SELECT p.id,p.title FROM saved_projects s JOIN projects p ON p.id=s.project_id WHERE s.user_id=$1'),
    q('SELECT id,name,status FROM servers WHERE user_id=$1 ORDER BY id DESC'),
    q('SELECT action,detail,created_at FROM activity WHERE user_id=$1 ORDER BY id DESC LIMIT 20'),
  ]);
  const L = ({ rows, base }) => rows.length ? <div className="list">{rows.map((r) => <Link key={r.id} className="card" href={`${base}/${r.id}`}>{r.title || r.name}</Link>)}</div> : <p className="muted">—</p>;
  return (<>
    <div className="row" style={{ margin: '24px 0' }}>{u.avatar_url ? <img className="avatar" src={u.avatar_url} alt="" /> : <div className="avatar" />}
      <div><h2 style={{ margin: 0 }}>{u.username}</h2><span className="muted">{u.email}</span></div></div>
    <AccountForm lang={lang} avatar={u.avatar_url || ''} />
    <h2>{tx('الدروس المكتملة', 'Completed lessons')} ({prog.length})</h2><L rows={prog} base="/learn" />
    <h2>{tx('مشاريعي المحفوظة', 'Saved projects')}</h2><L rows={saved} base="/projects" />
    <h2>{tx('استضافاتي', 'My servers')}</h2><L rows={servers} base="/hosting" />
    <h2>{tx('سجل النشاط', 'Activity log')}</h2>
    <div className="list">{act.map((a, i) => <div className="card muted" key={i}>{a.action} {a.detail && '· ' + a.detail} · {new Date(a.created_at).toLocaleString(lang === 'ar' ? 'ar' : 'en')}</div>)}</div>
  </>);
}
