import './globals.css';
import Navbar from '@/components/Navbar';
import { getUser } from '@/lib/auth';
import { dict, getLang, getTheme } from '@/lib/i18n';
export const metadata = { title: 'CODEX', description: 'Learn, build, host.' };
export default async function RootLayout({ children }) {
  const lang = getLang(), theme = getTheme(), user = await getUser();
  return (
    <html lang={lang} dir={dict[lang].dir} data-theme={theme}>
      <body>
        <Navbar t={dict[lang]} lang={lang} theme={theme} user={user && { username: user.username, role: user.role }} />
        <main className="wrap">{children}</main>
      </body>
    </html>
  );
}
