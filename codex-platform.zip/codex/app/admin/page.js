import { redirect } from 'next/navigation';
import { getUser } from '@/lib/auth';
import { getLang } from '@/lib/i18n';
import Admin from '@/components/Admin';
export const dynamic = 'force-dynamic';
export default async function AdminPage() {
  const u = await getUser(); if (!u || u.role !== 'owner') redirect('/');
  return <Admin lang={getLang()} />;
}
