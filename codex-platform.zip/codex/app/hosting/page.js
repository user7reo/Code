import Link from 'next/link';
import { redirect } from 'next/navigation';
import { pool } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { getLang, tr } from '@/lib/i18n';
import { getPlan } from '@/lib/servers';
import HostCreate from '@/components/HostCreate';
export const dynamic = 'force-dynamic';
export default async function Hosting() {
  const user = await getUser(); if (!user) redirect('/login');
  const lang = getLang(), tx = tr(lang), plan = await getPlan(user.id);
  const { rows } = await pool.query('SELECT id,name,runtime,status FROM servers WHERE user_id=$1 ORDER BY id DESC', [user.id]);
  const full = user.role !== 'owner' && rows.length >= plan.max_servers;
  return (<>
    <h2>{tx('استضافة البوتات', 'Bot hosting')}</h2>
    <div className="card"><b>{tx('خطتك', 'Your plan')}: {plan.name}</b>
      <p className="muted" style={{ margin: '6px 0 0' }}>{rows.length}/{plan.max_servers} {tx('استضافات', 'servers')} · {plan.memory_mb}MB RAM · {Number(plan.cpu)} CPU</p></div>
    {!full ? <HostCreate lang={lang} /> : <p className="muted">{tx('وصلت حد خطتك. تواصل مع المالك للترقية.', 'Plan limit reached. Contact the owner to upgrade.')}</p>}
    <div className="grid" style={{ marginTop: 16 }}>{rows.map((s) => (
      <Link key={s.id} href={`/hosting/${s.id}`} className="card"><b>{s.name}</b>
        <div><span className={'badge ' + (s.status === 'online' ? 'on' : 'off')}>{s.status === 'online' ? 'Online' : 'Offline'}</span><span className="badge">{s.runtime}</span></div></Link>))}</div>
  </>);
}
