import { notFound, redirect } from 'next/navigation';
import { getUser } from '@/lib/auth';
import { getLang } from '@/lib/i18n';
import { own, getPlan } from '@/lib/servers';
import { dec } from '@/lib/crypto';
import HostPanel from '@/components/HostPanel';
export const dynamic = 'force-dynamic';
export default async function Server({ params }) {
  const user = await getUser(); if (!user) redirect('/login');
  let s; try { s = await own(params.id, user); } catch { notFound(); }
  const plan = await getPlan(s.user_id);
  return <HostPanel id={s.id} lang={getLang()} plan={{ name: plan.name, memory_mb: plan.memory_mb, cpu: Number(plan.cpu) }}
    init={{ name: s.name, runtime: s.runtime, start_cmd: s.start_cmd, status: s.status, envKeys: Object.keys(dec(s.env_enc)) }} />;
}
