import Link from 'next/link';
import { pool } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { getLang, tr } from '@/lib/i18n';
import { LANGS } from '@/lib/consts';
export const dynamic = 'force-dynamic';
export default async function Search({ searchParams }) {
  const lang = getLang(), tx = tr(lang), q = String(searchParams.q || '').slice(0, 80), user = await getUser(), like = `%${q}%`;
  const [pr, ls, sv] = await Promise.all([
    pool.query('SELECT id,title FROM projects WHERE title ILIKE $1 OR description ILIKE $1 OR language ILIKE $1 LIMIT 20', [like]),
    pool.query('SELECT id,title FROM lessons WHERE title ILIKE $1 OR language ILIKE $1 LIMIT 20', [like]),
    user ? pool.query('SELECT id,name AS title FROM servers WHERE user_id=$1 AND name ILIKE $2 LIMIT 20', [user.id, like]) : { rows: [] },
  ]);
  const langs = LANGS.filter((l) => l.toLowerCase().includes(q.toLowerCase()));
  const Sec = ({ title, rows, base }) => rows.length > 0 && <><h2>{title}</h2><div className="list">{rows.map((r) => <Link key={r.id} className="card" href={`${base}/${r.id}`}>{r.title}</Link>)}</div></>;
  const none = !pr.rows.length && !ls.rows.length && !sv.rows.length && !langs.length;
  return (<>
    <h2>{tx('نتائج البحث عن', 'Search results for')} “{q}”</h2>
    {langs.length > 0 && <div className="row">{langs.map((l) => <Link key={l} className="btn" href={`/learn?language=${encodeURIComponent(l)}`}>{l}</Link>)}</div>}
    <Sec title={tx('الدروس', 'Lessons')} rows={ls.rows} base="/learn" /><Sec title={tx('المشاريع', 'Projects')} rows={pr.rows} base="/projects" />
    <Sec title={tx('استضافاتي', 'My servers')} rows={sv.rows} base="/hosting" />{none && <p className="muted">{tx('لا نتائج.', 'No results.')}</p>}
  </>);
}
