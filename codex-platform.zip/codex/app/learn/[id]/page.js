import Link from 'next/link';
import { notFound } from 'next/navigation';
import { pool } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { getLang, tr } from '@/lib/i18n';
import { LEVELS } from '@/lib/consts';
import CodeBlock from '@/components/CodeBlock';
import LessonClient from '@/components/LessonClient';
export const dynamic = 'force-dynamic';
export default async function Lesson({ params }) {
  if (!/^\d{1,9}$/.test(params.id)) notFound();
  const lang = getLang(), tx = tr(lang), user = await getUser();
  const { rows: [l] } = await pool.query('SELECT * FROM lessons WHERE id=$1', [params.id]);
  if (!l) notFound();
  const { rows: [nx] } = await pool.query('SELECT id,title FROM lessons WHERE language IS NOT DISTINCT FROM $1 AND (position,id) > ($2,$3) ORDER BY position,id LIMIT 1', [l.language, l.position, l.id]);
  const done = user ? (await pool.query('SELECT 1 FROM lesson_progress WHERE user_id=$1 AND lesson_id=$2', [user.id, l.id])).rowCount > 0 : false;
  const paras = (s) => s.split(/\n{2,}/).filter(Boolean).map((x, i) => <p key={i} style={{ whiteSpace: 'pre-wrap', lineHeight: 1.8 }}>{x}</p>);
  return (<>
    <p className="muted"><Link href={`/learn?language=${encodeURIComponent(l.language || '')}`}>{l.language}</Link> · {LEVELS[l.level] ? tx(...LEVELS[l.level]) : l.level}</p>
    <h1>{l.title}</h1>{paras(l.content)}
    {l.code && (<><h2>{tx('مثال', 'Example')}</h2><CodeBlock code={l.code} lang={lang} />{l.code_explain && <div className="card">{paras(l.code_explain)}</div>}</>)}
    <LessonClient id={l.id} done={done} loggedIn={!!user} playground={l.playground} quiz={l.quiz} lang={lang} nextId={nx?.id || null} />
  </>);
}
