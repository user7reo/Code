import Link from 'next/link';
import { pool } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { getLang, tr } from '@/lib/i18n';
import { LANGS, LEVELS } from '@/lib/consts';
export const dynamic = 'force-dynamic';
export default async function Learn({ searchParams }) {
  const lang = getLang(), tx = tr(lang), user = await getUser();
  const { q = '', language = '', level = '' } = searchParams;
  const w = [], p = [];
  if (q) { p.push(`%${q}%`); w.push(`title ILIKE $${p.length}`); }
  if (LANGS.includes(language)) { p.push(language); w.push(`language=$${p.length}`); }
  if (LEVELS[level]) { p.push(level); w.push(`level=$${p.length}`); }
  const { rows } = await pool.query(`SELECT id,title,language,level FROM lessons ${w.length ? 'WHERE ' + w.join(' AND ') : ''}
    ORDER BY language, CASE level WHEN 'beginner' THEN 1 WHEN 'intermediate' THEN 2 ELSE 3 END, position, id`, p);
  const done = user ? new Set((await pool.query('SELECT lesson_id FROM lesson_progress WHERE user_id=$1', [user.id])).rows.map((r) => r.lesson_id)) : new Set();
  const completed = rows.filter((r) => done.has(r.id)).length, pct = rows.length ? Math.round(completed / rows.length * 100) : 0;
  const groups = {}; rows.forEach((r) => { (groups[r.language || '—'] ||= []).push(r); });
  return (<>
    <h2>{tx('تعليم البرمجة', 'Learn programming')}</h2>
    <form className="filters"><input name="q" defaultValue={q} placeholder={tx('ابحث في الدروس', 'Search lessons')} />
      <select name="language" defaultValue={language}><option value="">{tx('كل اللغات', 'All languages')}</option>{LANGS.map((l) => <option key={l}>{l}</option>)}</select>
      <select name="level" defaultValue={level}><option value="">{tx('كل المستويات', 'All levels')}</option>{Object.entries(LEVELS).map(([k, v]) => <option key={k} value={k}>{tx(...v)}</option>)}</select>
      <button className="btn primary">{tx('تصفية', 'Filter')}</button></form>
    {user && rows.length > 0 && <div className="card"><div className="row" style={{ justifyContent: 'space-between' }}><span>{tx('تقدمك', 'Your progress')}</span><b>{completed}/{rows.length}</b></div><div className="bar"><i style={{ width: pct + '%' }} /></div></div>}
    {rows.length === 0 && <p className="muted">{tx('لا توجد دروس بعد.', 'No lessons yet.')}</p>}
    {Object.entries(groups).map(([g, ls]) => (<section key={g}><h2>{g}</h2><div className="grid">
      {ls.map((l) => <Link key={l.id} href={`/learn/${l.id}`} className="card"><b>{done.has(l.id) && <span className="ok">✓ </span>}{l.title}</b>
        <div><span className="badge">{LEVELS[l.level] ? tx(...LEVELS[l.level]) : l.level}</span></div></Link>)}
    </div></section>))}
  </>);
}
