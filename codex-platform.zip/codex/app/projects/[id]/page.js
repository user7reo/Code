import { notFound } from 'next/navigation';
import { pool } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { getLang, tr } from '@/lib/i18n';
import { LEVELS, CATEGORIES } from '@/lib/consts';
import CodeBlock from '@/components/CodeBlock';
import SaveButton from '@/components/SaveButton';
export const dynamic = 'force-dynamic';
export default async function Project({ params }) {
  if (!/^\d{1,9}$/.test(params.id)) notFound();
  const lang = getLang(), tx = tr(lang), user = await getUser();
  const { rows: [p] } = await pool.query('SELECT * FROM projects WHERE id=$1', [params.id]);
  if (!p) notFound();
  const saved = user ? (await pool.query('SELECT 1 FROM saved_projects WHERE user_id=$1 AND project_id=$2', [user.id, p.id])).rowCount > 0 : false;
  const canDl = p.zip_path || p.download_url;
  return (<>
    {p.image_url && /^https?:\/\//.test(p.image_url) && <img className="cover" style={{ height: 220, marginTop: 16 }} src={p.image_url} alt="" />}
    <h1>{p.title}</h1>
    <p>{p.language && <span className="badge">{p.language}</span>}{LEVELS[p.level] && <span className="badge">{tx(...LEVELS[p.level])}</span>}{CATEGORIES[p.category] && <span className="badge">{tx(...CATEGORIES[p.category])}</span>}<span className="badge">⬇ {p.downloads}</span></p>
    <p style={{ whiteSpace: 'pre-wrap', lineHeight: 1.8 }}>{p.description}</p>
    <div className="row">
      {canDl && <a className="btn primary" href={`/api/projects/${p.id}/download`}>{tx('تحميل المشروع', 'Download project')}</a>}
      {p.github_url && /^https:\/\//.test(p.github_url) && <a className="btn" href={p.github_url} target="_blank" rel="noreferrer">GitHub</a>}
      <SaveButton id={p.id} saved={saved} loggedIn={!!user} lang={lang} /></div>
    {p.files && <><h2>{tx('الملفات', 'Files')}</h2><div className="card" style={{ whiteSpace: 'pre-wrap', direction: 'ltr', textAlign: 'left' }}>{p.files}</div></>}
    {p.run_guide && <><h2>{tx('طريقة التشغيل', 'How to run')}</h2><div className="card" style={{ whiteSpace: 'pre-wrap', lineHeight: 1.8 }}>{p.run_guide}</div></>}
    {p.code_preview && <><h2>{tx('الكود', 'Code')}</h2><CodeBlock code={p.code_preview} lang={lang} /></>}
  </>);
}
