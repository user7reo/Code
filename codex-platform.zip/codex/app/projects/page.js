import Link from 'next/link';
import { pool } from '@/lib/db';
import { getLang, tr } from '@/lib/i18n';
import { LANGS, LEVELS, CATEGORIES } from '@/lib/consts';
export const dynamic = 'force-dynamic';
export default async function Projects({ searchParams }) {
  const lang = getLang(), tx = tr(lang);
  const { q = '', category = '', language = '', level = '' } = searchParams;
  const w = [], p = [];
  if (q) { p.push(`%${q}%`); w.push(`(title ILIKE $${p.length} OR description ILIKE $${p.length})`); }
  if (CATEGORIES[category]) { p.push(category); w.push(`category=$${p.length}`); }
  if (LANGS.includes(language)) { p.push(language); w.push(`language=$${p.length}`); }
  if (LEVELS[level]) { p.push(level); w.push(`level=$${p.length}`); }
  const { rows } = await pool.query(`SELECT id,title,description,image_url,language,level,category FROM projects ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY created_at DESC LIMIT 100`, p);
  const sel = (name, val, all, opts) => <select name={name} defaultValue={val}><option value="">{all}</option>{opts.map(([k, label]) => <option key={k} value={k}>{label}</option>)}</select>;
  return (<>
    <h2>{tx('مكتبة المشاريع المجانية', 'Free projects library')}</h2>
    <form className="filters"><input name="q" defaultValue={q} placeholder={tx('ابحث', 'Search')} />
      {sel('category', category, tx('كل الأنواع', 'All types'), Object.entries(CATEGORIES).map(([k, v]) => [k, tx(...v)]))}
      {sel('language', language, tx('كل اللغات', 'All languages'), LANGS.map((l) => [l, l]))}
      {sel('level', level, tx('كل المستويات', 'All levels'), Object.entries(LEVELS).map(([k, v]) => [k, tx(...v)]))}
      <button className="btn primary">{tx('تصفية', 'Filter')}</button></form>
    {rows.length === 0 && <p className="muted">{tx('لا توجد مشاريع بعد.', 'No projects yet.')}</p>}
    <div className="grid">{rows.map((r) => (
      <Link href={`/projects/${r.id}`} className="card" key={r.id}>
        {r.image_url && /^https?:\/\//.test(r.image_url) && <img className="cover" src={r.image_url} alt="" loading="lazy" />}
        <b>{r.title}</b><p className="muted" style={{ margin: '6px 0' }}>{r.description.slice(0, 90)}</p>
        {r.language && <span className="badge">{r.language}</span>}{LEVELS[r.level] && <span className="badge">{tx(...LEVELS[r.level])}</span>}</Link>))}</div>
  </>);
}
