import Link from 'next/link';
import { pool } from '@/lib/db';
import { dict, getLang, tr } from '@/lib/i18n';
export const dynamic = 'force-dynamic';
export default async function Home() {
  const lang = getLang(), t = dict[lang], tx = tr(lang);
  const [u, p, l, lp, ll] = await Promise.all([
    pool.query('SELECT count(*)::int c FROM users'), pool.query('SELECT count(*)::int c FROM projects'), pool.query('SELECT count(*)::int c FROM lessons'),
    pool.query('SELECT id,title,description FROM projects ORDER BY created_at DESC LIMIT 6'), pool.query('SELECT id,title,language FROM lessons ORDER BY created_at DESC LIMIT 6'),
  ]);
  const Stat = ({ n, label }) => <div className="card stat"><b>{n}</b><span>{label}</span></div>;
  const List = ({ rows, sub, base }) => rows.length
    ? <div className="list">{rows.map((r) => <Link href={`${base}/${r.id}`} className="card" key={r.id}><b>{r.title}</b><div className="muted">{r[sub]}</div></Link>)}</div>
    : <p className="muted">{t.empty}</p>;
  return (<>
    <section className="hero"><h1>{t.tagline}</h1><p>{t.desc}</p>
      <div className="row" style={{ justifyContent: 'center' }}>
        <Link className="btn primary" href="/learn">{tx('ابدأ التعلّم', 'Start learning')}</Link>
        <Link className="btn" href="/hosting">{tx('استضف بوتك', 'Host a bot')}</Link></div></section>
    <div className="stats"><Stat n={u.rows[0].c} label={t.users} /><Stat n={p.rows[0].c} label={t.projects} /><Stat n={l.rows[0].c} label={t.courses} /></div>
    <h2>{t.latestProjects}</h2><List rows={lp.rows} sub="description" base="/projects" />
    <h2>{t.latestLessons}</h2><List rows={ll.rows} sub="language" base="/learn" />
  </>);
}
