import AuthForm from '@/components/AuthForm';
import { dict, getLang } from '@/lib/i18n';
export default function Page() { return <AuthForm mode="login" t={dict[getLang()]} />; }
